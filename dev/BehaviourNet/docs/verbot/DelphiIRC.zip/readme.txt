Hi,
I've made this conversion because I am a Delphi programmer and I've never
seen a IRC Client in Delphi with full source code.
This program was made originally by Dann Daggett II (man, your email isn't
working, or my isp is owned by a Lammer).
You can see the original reamde at ircpre2.txt.
I've included a little animation in the about form... just to be different...
Ah, if you use this source code for any purpose, all that I ask is to let me
know.
enjoy...

Cristiano M. Ferreira
lebeau@linuxbr.com.br
http://lbworld.cjb.net


